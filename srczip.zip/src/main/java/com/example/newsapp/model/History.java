package com.example.newsapp.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "history")
public class History {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private AppUser user;

    // Instead of referencing an Article entity,
    // we directly store the article fields in History.
    private String title;
    private String description;
    private String url;
    private String imageUrl;
}
