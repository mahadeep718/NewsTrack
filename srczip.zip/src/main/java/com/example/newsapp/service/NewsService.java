package com.example.newsapp.service;

import com.example.newsapp.dto.ArticleDto;
import org.json.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class NewsService {

    @Value("${newsapi.key}")
    private String apiKey;

    private final String url = "https://newsapi.org/v2/top-headlines?country=us&apiKey=";

    public List<ArticleDto> getTopNews() {
        RestTemplate rest = new RestTemplate();
        String resp = rest.getForObject(url + apiKey, String.class);

        List<ArticleDto> articles = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(resp);
            JSONArray arr = obj.getJSONArray("articles");
            for(int i=0;i<arr.length();i++){
                JSONObject a = arr.getJSONObject(i);
                ArticleDto dto = new ArticleDto(
                        a.getString("title"),
                        a.optString("description"),
                        a.getString("url"),
                        a.optString("urlToImage")
                );
                articles.add(dto);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return articles;
    }
}
